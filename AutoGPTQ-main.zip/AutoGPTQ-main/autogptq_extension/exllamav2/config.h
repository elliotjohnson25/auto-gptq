#ifndef _config_h
#define _config_h

#define MAX_Q_GEMM_ROWS 50

#define QMODE_2BIT 1
#define QMODE_3BIT 1
#define QMODE_4BIT 1
#define QMODE_5BIT 1
#define QMODE_6BIT 0
#define QMODE_8BIT 0

#endif
